#!/usr/bin/env python3
import time
import subprocess
from kubernetes import client, config
from kubernetes.client.rest import ApiException

# ---------------- CONFIG ----------------
NAMESPACE = "default"
KAFKA_NAMESPACE = "kafka"
BROKER_NAME = "kafka-broker"

KNATIVE_MANIFESTS = [
    "manifests/eventing-crds.yaml",
    "manifests/eventing-core.yaml",
    "manifests/eventing-kafka-controller.yaml",
    "manifests/eventing-kafka-broker.yaml",
]

STRIMZI_MANIFEST = "manifests/strimzi.yaml"
KAFKA_CLUSTER_MANIFEST = "kafka_cluster_conf.yaml"

# ---------------- UTILS ----------------
def run(cmd):
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"❌ Error: {' '.join(cmd)}\n{result.stderr}")
        raise Exception(result.stderr)
    return result.stdout.strip()

def apply(filepath, namespace=None):
    cmd = ["kubectl", "apply", "-f", filepath]
    if namespace:
        cmd += ["-n", namespace]
    print(f"🚀 Applying {filepath}")
    run(cmd)

# ---------------- WAIT ----------------
def wait_for_pods(namespace, label, timeout=180):
    print(f"⏳ Waiting pods [{label}] in {namespace}")
    for _ in range(timeout // 5):
        out = run(["kubectl", "get", "pods", "-n", namespace, "-l", label, "--no-headers"])
        if out:
            if all("Running" in line for line in out.splitlines()):
                print("✅ Pods ready")
                return True
        time.sleep(5)
    raise Exception(f"Timeout pods {label}")

def wait_for_crd(name):
    print(f"⏳ Waiting CRD {name}")
    for _ in range(60):
        try:
            run(["kubectl", "get", "crd", name])
            return
        except:
            time.sleep(2)
    raise Exception(f"CRD {name} not ready")

def wait_for_broker():
    print("⏳ Waiting Broker READY")
    for _ in range(60):
        try:
            status = run([
                "kubectl", "get", "broker", BROKER_NAME,
                "-n", NAMESPACE,
                "-o", "jsonpath={.status.conditions[?(@.type=='Ready')].status}"
            ])
            if status == "True":
                print("✅ Broker ready")
                return
        except:
            pass
        time.sleep(5)
    raise Exception("Broker not ready")

def wait_for_kafka():
    print("⏳ Waiting Kafka cluster")
    for _ in range(120):
        out = run(["kubectl", "get", "pods", "-n", KAFKA_NAMESPACE])
        if "demo-kafka" in out and "Running" in out:
            print("✅ Kafka ready")
            return
        time.sleep(5)
    raise Exception("Kafka not ready")

# ---------------- CREATE ----------------
def create_namespace(v1, name):
    try:
        v1.read_namespace(name)
    except ApiException:
        v1.create_namespace(client.V1Namespace(metadata=client.V1ObjectMeta(name=name)))
        print(f"✅ Namespace {name}")

def create_kafka_config():
    print("🚀 Creating Kafka config")
    run([
        "kubectl", "apply", "-f", "-"
    ],)

def create_broker():
    print("🚀 Creating Broker")
    run([
        "kubectl", "apply", "-f", "-"
    ])

    subprocess.run(f"""
cat <<EOF | kubectl apply -f -
apiVersion: v1
kind: ConfigMap
metadata:
  name: kafka-broker-config
  namespace: knative-eventing
data:
  bootstrap.servers: demo-kafka-bootstrap.kafka.svc:9092
  default.topic.partitions: "3"
  default.topic.replication.factor: "1"
---
apiVersion: eventing.knative.dev/v1
kind: Broker
metadata:
  name: {BROKER_NAME}
  namespace: {NAMESPACE}
  annotations:
    eventing.knative.dev/broker.class: Kafka
spec:
  config:
    apiVersion: v1
    kind: ConfigMap
    name: kafka-broker-config
    namespace: knative-eventing
EOF
""", shell=True)

def create_services_and_triggers():
    print("🚀 Creating services + triggers")

    subprocess.run(f"""
cat <<EOF | kubectl apply -f -
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: request-processor
  namespace: {NAMESPACE}
spec:
  template:
    spec:
      containers:
      - image: tomasconti02/request-processor:v1
        env:
        - name: TIPO
          value: request
---
apiVersion: serving.knative.dev/v1
kind: Service
metadata:
  name: response-processor
  namespace: {NAMESPACE}
spec:
  template:
    spec:
      containers:
      - image: tomasconti02/request-processor:v1
        env:
        - name: TIPO
          value: response
---
apiVersion: eventing.knative.dev/v1
kind: Trigger
metadata:
  name: trigger-request
  namespace: {NAMESPACE}
spec:
  broker: {BROKER_NAME}
  filter:
    attributes:
      type: org.kubeflow.serving.inference.request
  subscriber:
    ref:
      apiVersion: serving.knative.dev/v1
      kind: Service
      name: request-processor
---
apiVersion: eventing.knative.dev/v1
kind: Trigger
metadata:
  name: trigger-response
  namespace: {NAMESPACE}
spec:
  broker: {BROKER_NAME}
  filter:
    attributes:
      type: org.kubeflow.serving.inference.response
  subscriber:
    ref:
      apiVersion: serving.knative.dev/v1
      kind: Service
      name: response-processor
EOF
""", shell=True)

# ---------------- MAIN ----------------
def main():
    config.load_kube_config()
    v1 = client.CoreV1Api()

    create_namespace(v1, KAFKA_NAMESPACE)

    # 1️⃣ Knative install
    for f in KNATIVE_MANIFESTS:
        apply(f)

    wait_for_pods("knative-eventing", "app=eventing-webhook")
    wait_for_pods("knative-eventing", "app=kafka-controller")

    # 2️⃣ Kafka (Strimzi)
    apply(STRIMZI_MANIFEST, KAFKA_NAMESPACE)
    wait_for_crd("kafkas.kafka.strimzi.io")

    apply(KAFKA_CLUSTER_MANIFEST, KAFKA_NAMESPACE)
    wait_for_kafka()

    # 3️⃣ Broker
    create_broker()
    wait_for_broker()

    # 4️⃣ Services + triggers
    create_services_and_triggers()

    print("\n🎉 SYSTEM READY!")

if __name__ == "__main__":
    main()
