"""
docker build -t tomasconti02/request-processor:v1 .
docker push tomasconti02/request-processor:v1
kubectl delete ksvc request-processor response-processor -n default

"""
from fastapi import FastAPI, Request, Response
import uvicorn
import os
import json
from cloudevents.http import from_http
from collections import defaultdict

app = FastAPI()
message_counter = defaultdict(int)

# Abilita il debug con variabile d'ambiente (es. DEBUG=true)
DEBUG = os.getenv("DEBUG", "false").lower() == "true"


@app.post("/")
async def handle_event(request: Request):
    body = await request.body()
    headers = dict(request.headers)

    event_data = None
    event_type = "unknown"

    # prova CloudEvent
    try:
        event = from_http(headers, body)
        event_data = event.get("data")
        event_type = event.get("type", "cloudevent")
    except Exception:
        pass

    # fallback: parsing diretto JSON
    if not event_data:
        try:
            raw_json = json.loads(body)
            event_data = raw_json.get("data") or raw_json
            event_type = raw_json.get("type", "raw_http")
        except Exception as e:
            print("❌ Failed to parse raw body:", e)

    # contatore
    message_counter[event_type] += 1

    # LOG DETTAGLIATO
    print(f"\n✅ Event received: {event_type} (total: {message_counter[event_type]})")
    if event_data:
        # Se event_data è dict, stampalo formattato
        if isinstance(event_data, dict):
            print("📦 DATA PAYLOAD (dict):")
            print(json.dumps(event_data, indent=2))
        elif isinstance(event_data, list):
            print(f"📦 DATA PAYLOAD (list, {len(event_data)} items):")
            # Stampiamo solo i primi 5 elementi se la lista è lunga
            preview = event_data[:5] if len(event_data) > 5 else event_data
            print(json.dumps(preview, indent=2))
        else:
            print(f"📦 DATA PAYLOAD (type {type(event_data)}): {event_data}")
    else:
        print("⚠️ No data payload")

    return {"status": "ok"}


@app.get("/count")
def get_counts():
    return dict(message_counter)

@app.get("/health")
def health():
    return {"status": "ok"}

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    uvicorn.run(app, host="0.0.0.0", port=port)




"""
from flask import Flask, request, jsonify
import os
import json

app = Flask(__name__)

@app.route('/', methods=['POST'])
def handle_event():
    # Riceve l'evento (CloudEvent)
    event = request.get_json()
    print(f"Evento ricevuto: {json.dumps(event)}")

    # Esempio: estrai i dati utili
    event_type = event.get('type')
    event_data = event.get('data', {})

    # --- QUI LA TUA LOGICA PERSONALIZZATA ---
    # Ad esempio: salva su database, invia a un'altra API, ecc.
    # ...

    # Rispondi con successo (202 ACCEPTED è tipico per eventi)
    return jsonify({"status": "ok"}), 202

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port)
"""