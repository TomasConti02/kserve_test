#!/usr/bin/env python3
r"""
kubectl get pods -n default -l serving.knative.dev/service=request-processor
kubectl get pods -n default -l serving.knative.dev/service=response-processor

kubectl get knative

kubectl logs -n default -l serving.knative.dev/service=response-processor | grep "POST" | wc -l
kubectl logs -n default -l serving.knative.dev/service=request-processor | grep "POST" | wc -l

kubectl exec -it -n kafka demo-pool-a-0 -- bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --topic knative-broker-default-kafka-broker \
  --from-beginning
"""
import time
import subprocess
from kubernetes import client, config, utils
from kubernetes.client.rest import ApiException
from kubernetes.client import ApiClient

# ---------------- CONFIG ----------------
NAMESPACE = "default"
KAFKA_NAMESPACE = "kafka"
BROKER_NAME = "kafka-broker"
KNATIVE_EVENTING_NAMESPACE = "knative-eventing"

# Local Knative core manifests (must exist in the manifests/ directory)
KNATIVE_CORE_MANIFESTS = [
    "manifests/eventing-crds.yaml",
    "manifests/eventing-core.yaml",
]

# Official Knative Kafka manifests from GitHub (latest for v1.19.8)
KAFKA_MANIFESTS_URLS = [
    "https://github.com/knative-extensions/eventing-kafka-broker/releases/download/knative-v1.19.8/eventing-kafka-controller.yaml",
    "https://github.com/knative-extensions/eventing-kafka-broker/releases/download/knative-v1.19.8/eventing-kafka-broker.yaml",
]

STRIMZI_MANIFEST = "manifests/strimzi.yaml"
KAFKA_CLUSTER_MANIFEST = "kafka_cluster_conf.yaml"

# ---------------- LOAD CONFIG ----------------
def load_k8s_config():
    try:
        config.load_incluster_config()
        print("In-cluster config loaded")
    except:
        config.load_kube_config()
        print("Local kubeconfig loaded")
    return ApiClient()

# ---------------- CREATE NAMESPACE ----------------
def create_namespace_if_not_exists(v1, namespace):
    try:
        v1.read_namespace(namespace)
        print(f"ℹ️ Namespace '{namespace}' already exists")
    except ApiException as e:
        if e.status == 404:
            ns_body = client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
            v1.create_namespace(ns_body)
            print(f"✅ Namespace '{namespace}' created")
        else:
            raise

# ---------------- APPLY YAML WITH KUBECTL (file or URL) ----------------
def apply_yaml_with_kubectl(source, namespace=None):
    """Apply a YAML file or URL using kubectl."""
    cmd = ["kubectl", "apply", "-f", source]
    if namespace:
        cmd.extend(["-n", namespace])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"✅ Applied {source}")
        if result.stdout:
            print(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        if "AlreadyExists" in e.stderr:
            print(f"ℹ️ {source} already exists, skipping")
        else:
            print(f"❌ Error applying {source}: {e.stderr}")
            raise

# ---------------- APPLY LOCAL YAML WITH PYTHON CLIENT ----------------
def apply_yaml_from_file(k8s_client, filepath, namespace=None):
    try:
        utils.create_from_yaml(k8s_client, filepath, namespace=namespace)
        print(f"✅ Applied {filepath}")
    except Exception as e:
        if "AlreadyExists" in str(e):
            print(f"ℹ️ {filepath} already exists, skipping")
        else:
            print(f"❌ Error applying {filepath}: {e}")
            raise

# ---------------- WAIT FOR PODS READY ----------------
def wait_for_pod_ready(namespace, label_selector, timeout=120):
    print(f"⏳ Waiting for pods with label {label_selector} in namespace {namespace} to be ready...")
    v1 = client.CoreV1Api()
    elapsed = 0
    while elapsed < timeout:
        pods = v1.list_namespaced_pod(namespace, label_selector=label_selector)
        if all(pod.status.phase == "Running" for pod in pods.items):
            print(f"✅ All pods are ready.")
            return True
        time.sleep(5)
        elapsed += 5
        print(f"   Still waiting... ({elapsed}s)")
    print(f"❌ Timeout waiting for pods.")
    return False

# ---------------- WAIT FOR CRD ----------------
def wait_for_crd(crd_name, timeout=120, interval=5):
    print(f"⏳ Waiting for CRD {crd_name} to be established...")
    elapsed = 0
    while elapsed < timeout:
        try:
            subprocess.run(["kubectl", "get", "crd", crd_name], capture_output=True, text=True, check=True)
            result = subprocess.run(
                ["kubectl", "get", "crd", crd_name,
                 "-o", "jsonpath='{.status.conditions[?(@.type==\"Established\")].status}'"],
                capture_output=True, text=True, check=True
            )
            status = result.stdout.strip().strip("'")
            if status == "True":
                print(f"✅ CRD {crd_name} is ready.")
                return True
        except subprocess.CalledProcessError:
            pass
        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")
    print(f"❌ Timeout waiting for CRD {crd_name}")
    return False

# ---------------- WAIT FOR KAFKA ----------------
def wait_for_kafka(v1, timeout=300, interval=5):
    print("⏳ Waiting for Kafka cluster to be ready...")
    elapsed = 0
    while elapsed < timeout:
        try:
            pods = v1.list_namespaced_pod(KAFKA_NAMESPACE)
            kafka_pods = [p for p in pods.items if p.metadata.name.startswith("demo-")]
            if kafka_pods and all(p.status.phase == "Running" for p in kafka_pods):
                print("✅ Kafka cluster is ready!")
                return True
        except Exception as e:
            print(f"Error checking Kafka pods: {e}")
        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")
    print("❌ Timeout waiting for Kafka cluster")
    return False

# ---------------- WAIT FOR KNATIVE KAFKA DATA PLANE ----------------
def wait_for_knative_kafka_dataplane(namespace=KNATIVE_EVENTING_NAMESPACE, timeout=180):
    """Wait for both kafka-broker-dispatcher and kafka-broker-receiver to be ready."""
    print("⏳ Waiting for Knative Kafka data plane to be ready...")
    v1 = client.CoreV1Api()
    dataplane_labels = ["app=kafka-broker-dispatcher", "app=kafka-broker-receiver"]
    elapsed = 0
    while elapsed < timeout:
        all_ready = True
        for label in dataplane_labels:
            pods = v1.list_namespaced_pod(namespace, label_selector=label)
            if not pods.items or not all(p.status.phase == "Running" for p in pods.items):
                all_ready = False
                break
        if all_ready:
            print("✅ Knative Kafka data plane is ready.")
            return True
        time.sleep(5)
        elapsed += 5
        print(f"   Still waiting... ({elapsed}s)")
    print("❌ Timeout waiting for Knative Kafka data plane.")
    return False

# ---------------- CREATE CONFIGMAP ----------------
def create_or_update_kafka_configmap(v1):
    cm = client.V1ConfigMap(
        metadata=client.V1ObjectMeta(
            name="kafka-broker-config",
            namespace=KNATIVE_EVENTING_NAMESPACE
        ),
        data={
            "bootstrap.servers": "demo-kafka-bootstrap.kafka.svc:9092",
            "default.topic.partitions": "3",
            "default.topic.replication.factor": "1"
        }
    )
    try:
        v1.create_namespaced_config_map(KNATIVE_EVENTING_NAMESPACE, cm)
        print("✅ Kafka ConfigMap created")
    except ApiException as e:
        if e.status == 409:
            v1.replace_namespaced_config_map("kafka-broker-config", KNATIVE_EVENTING_NAMESPACE, cm)
            print("🔄 Kafka ConfigMap updated")
        else:
            raise

# ---------------- WAIT FOR KNATIVE WEBHOOK ----------------
def wait_for_knative_webhook(namespace=KNATIVE_EVENTING_NAMESPACE, timeout=120):
    print("⏳ Waiting for Knative Eventing webhook to be ready...")
    v1 = client.CoreV1Api()
    label_selector = "app=eventing-webhook"
    elapsed = 0
    while elapsed < timeout:
        pods = v1.list_namespaced_pod(namespace, label_selector=label_selector)
        if pods.items and all(pod.status.phase == "Running" for pod in pods.items):
            print("✅ Knative Eventing webhook is ready.")
            return True
        time.sleep(5)
        elapsed += 5
        print(f"   Still waiting... ({elapsed}s)")
    print("❌ Timeout waiting for Knative webhook.")
    return False

# ---------------- CREATE BROKER ----------------
def create_broker(custom_api):
    broker = {
        "apiVersion": "eventing.knative.dev/v1",
        "kind": "Broker",
        "metadata": {"name": BROKER_NAME, "namespace": NAMESPACE,
                     "annotations": {"eventing.knative.dev/broker.class": "Kafka"}},
        "spec": {
            "config": {
                "apiVersion": "v1",
                "kind": "ConfigMap",
                "name": "kafka-broker-config",
                "namespace": KNATIVE_EVENTING_NAMESPACE
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="eventing.knative.dev", version="v1",
            namespace=NAMESPACE, plural="brokers", body=broker
        )
        print("✅ Broker created")
    except ApiException as e:
        if e.status == 409:
            print("ℹ️ Broker already exists")
        else:
            raise

# ---------------- CREATE KNATIVE SERVICES ----------------
def create_knative_service(custom_api, name, tipo):
    body = {
        "apiVersion": "serving.knative.dev/v1",
        "kind": "Service",
        "metadata": {"name": name, "namespace": NAMESPACE},
        "spec": {
            "template": {
                "spec": {
                    "containers": [
                        {
                            "image": "tomasconti02/request-processor:v1",
                            "env": [{"name": "TIPO", "value": tipo}]
                        }
                    ]
                }
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="serving.knative.dev", version="v1",
            namespace=NAMESPACE, plural="services", body=body
        )
        print(f"✅ Knative Service '{name}' created")
    except ApiException as e:
        if e.status == 409:
            print(f"ℹ️ Knative Service '{name}' already exists")
        else:
            raise

# ---------------- CREATE TRIGGERS ----------------
def create_triggers(custom_api):
    triggers = [
        {"name": "trigger-request", "type": "org.kubeflow.serving.inference.request", "service": "request-processor"},
        {"name": "trigger-response", "type": "org.kubeflow.serving.inference.response", "service": "response-processor"}
    ]
    for t in triggers:
        body = {
            "apiVersion": "eventing.knative.dev/v1",
            "kind": "Trigger",
            "metadata": {"name": t["name"], "namespace": NAMESPACE},
            "spec": {
                "broker": BROKER_NAME,
                "filter": {"attributes": {"type": t["type"]}},
                "subscriber": {"ref": {"apiVersion": "serving.knative.dev/v1", "kind": "Service", "name": t["service"]}}
            }
        }
        try:
            custom_api.create_namespaced_custom_object(
                group="eventing.knative.dev", version="v1",
                namespace=NAMESPACE, plural="triggers", body=body
            )
            print(f"✅ Trigger '{t['name']}' created")
        except ApiException as e:
            if e.status == 409:
                print(f"ℹ️ Trigger '{t['name']}' already exists")
            else:
                raise

# ---------------- MAIN ----------------
def main():
    k8s_client = load_k8s_config()
    v1 = client.CoreV1Api(k8s_client)
    custom_api = client.CustomObjectsApi(k8s_client)

    # 0️⃣ Create Kafka namespace
    create_namespace_if_not_exists(v1, KAFKA_NAMESPACE)

    # 1️⃣ Apply core Knative Eventing manifests (CRDs, core)
    for filepath in KNATIVE_CORE_MANIFESTS:
        apply_yaml_from_file(k8s_client, filepath)

    # 2️⃣ Apply Knative Kafka manifests from official URLs
    for url in KAFKA_MANIFESTS_URLS:
        apply_yaml_with_kubectl(url)

    # 3️⃣ Wait for the Knative Eventing webhook to be ready
    if not wait_for_knative_webhook():
        print("❌ Knative Eventing webhook not ready. Abort deployment")
        return

    # 4️⃣ Wait for the Kafka data plane (dispatcher & receiver)
    if not wait_for_knative_kafka_dataplane():
        print("❌ Knative Kafka data plane not ready. Abort deployment")
        return

    # 5️⃣ Deploy Strimzi operator
    apply_yaml_with_kubectl(STRIMZI_MANIFEST, namespace=KAFKA_NAMESPACE)

    # 6️⃣ Wait for Strimzi operator pod
    if not wait_for_pod_ready(KAFKA_NAMESPACE, "app=strimzi"):
        print("❌ Strimzi operator pod not ready. Abort deployment")
        return

    # 7️⃣ Wait for Kafka CRD
    if not wait_for_crd("kafkas.kafka.strimzi.io"):
        print("❌ Kafka CRD not ready. Abort deployment")
        return

    # 8️⃣ Apply Kafka cluster
    apply_yaml_with_kubectl(KAFKA_CLUSTER_MANIFEST, namespace=KAFKA_NAMESPACE)

    # 9️⃣ Wait for Kafka cluster
    if not wait_for_kafka(v1):
        print("❌ Kafka cluster not ready. Abort deployment")
        return

    # 🔟 Create Kafka ConfigMap, Broker, Services, Triggers
    create_or_update_kafka_configmap(v1)
    time.sleep(3)  # allow ConfigMap propagation
    create_broker(custom_api)
    create_knative_service(custom_api, "request-processor", "request")
    create_knative_service(custom_api, "response-processor", "response")
    create_triggers(custom_api)

    print("\n🎉 Knative Eventing + Kafka setup completed!")

if __name__ == "__main__":
    main()