#!/usr/bin/env python3
"""
kubectl logs -n default -l serving.knative.dev/service=response-processor
kubectl logs -n default -l serving.knative.dev/service=request-processor

Deployment script for Knative Eventing with Kafka broker.

kubectl exec -it -n kafka demo-pool-a-0 -- bin/kafka-console-consumer.sh \
  --bootstrap-server localhost:9092 \
  --topic knative-broker-default-kafka-broker \
  --from-beginning
  


  apiVersion: apps/v1
kind: StatefulSet
metadata:
  name: kafka-broker-dispatcher
  namespace: knative-eventing
  ...
spec:
  serviceName: kafka-broker-dispatcher
  volumeClaimTemplates:                   # <--- Aggiungi qui
  - metadata:
      name: contract-resources
    spec:
      accessModes: ["ReadWriteOnce"]
      resources:
        requests:
          storage: 1Gi
      storageClassName: standard
  podManagementPolicy: "Parallel"
"""
import time
import subprocess
from kubernetes import client, config, utils
from kubernetes.client.rest import ApiException
from kubernetes.client import ApiClient

# ---------------- CONFIG ----------------
NAMESPACE = "default"
KAFKA_NAMESPACE = "kafka"
BROKER_NAME = "kafka-broker"

KNATIVE_MANIFESTS = [
    "manifests/eventing-crds.yaml",
    "manifests/eventing-core.yaml",
    "manifests/eventing-kafka-controller.yaml",
    "manifests/eventing-kafka-broker.yaml",
]

STRIMZI_MANIFEST = "manifests/strimzi.yaml"
KAFKA_CLUSTER_MANIFEST = "kafka_cluster_conf.yaml"

# ---------------- LOAD CONFIG ----------------
def load_k8s_config():
    try:
        config.load_incluster_config()
        print("In-cluster config loaded")
    except:
        config.load_kube_config()
        print("Local kubeconfig loaded")
    return ApiClient()

# ---------------- CREATE NAMESPACE ----------------
def create_namespace_if_not_exists(v1, namespace):
    try:
        v1.read_namespace(namespace)
        print(f"ℹ️ Namespace '{namespace}' already exists")
    except ApiException as e:
        if e.status == 404:
            ns_body = client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
            v1.create_namespace(ns_body)
            print(f"✅ Namespace '{namespace}' created")
        else:
            raise

# ---------------- APPLY YAML WITH KUBECTL ----------------
"""
def apply_yaml_with_kubectl(filepath, namespace=None):
    cmd = ["kubectl", "apply", "-f", filepath]
    if namespace:
        cmd.extend(["-n", namespace])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"✅ Applied {filepath}")
        if result.stdout:
            print(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        if "AlreadyExists" in e.stderr:
            print(f"ℹ️ {filepath} already exists, skipping")
        else:
            print(f"❌ Error applying {filepath}: {e.stderr}")
            raise
"""
def apply_yaml_with_kubectl(filepath, namespace=None):
    cmd = ["kubectl", "apply", "-f", filepath]
    if namespace:
        cmd.extend(["-n", namespace])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"✅ Applied {filepath}")
        if result.stdout:
            print(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        print(f"❌ Error applying {filepath}: {e.stderr}")
        raise

# ---------------- APPLY YAML WITH PYTHON CLIENT ----------------
def apply_yaml_from_file(k8s_client, filepath, namespace=None):
    try:
        utils.create_from_yaml(k8s_client, filepath, namespace=namespace)
        print(f"✅ Applied {filepath}")
    except Exception as e:
        if "AlreadyExists" in str(e):
            print(f"ℹ️ {filepath} already exists, skipping")
        else:
            print(f"❌ Error applying {filepath}: {e}")
            raise

# ---------------- WAIT FOR PODS READY (BY LABEL) ----------------
def wait_for_pod_ready(namespace, label_selector, timeout=120):
    """Wait for all pods matching the label selector to be Running."""
    print(f"⏳ Waiting for pods with label {label_selector} in namespace {namespace} to be ready...")
    v1 = client.CoreV1Api()
    elapsed = 0
    while elapsed < timeout:
        pods = v1.list_namespaced_pod(namespace, label_selector=label_selector)
        if all(pod.status.phase == "Running" for pod in pods.items):
            print(f"✅ All pods are ready.")
            return True
        time.sleep(5)
        elapsed += 5
        print(f"   Still waiting... ({elapsed}s)")
    print(f"❌ Timeout waiting for pods.")
    return False

# ---------------- WAIT FOR ALL PODS IN NAMESPACE TO BE READY ----------------
def wait_for_namespace_pods_ready(namespace, timeout=300):
    """Wait for all pods in the given namespace to be Running."""
    print(f"⏳ Waiting for all pods in namespace {namespace} to be ready...")
    v1 = client.CoreV1Api()
    start = time.time()
    while time.time() - start < timeout:
        pods = v1.list_namespaced_pod(namespace)
        if not pods.items:
            print(f"   No pods found in {namespace} yet...")
            time.sleep(5)
            continue
        all_ready = True
        for pod in pods.items:
            if pod.status.phase != "Running":
                all_ready = False
                break
        if all_ready:
            print(f"✅ All pods in namespace {namespace} are ready.")
            return True
        time.sleep(5)
        print(f"   Still waiting for pods in {namespace}...")
    print(f"❌ Timeout waiting for pods in namespace {namespace}")
    return False

# ---------------- WAIT FOR CRD ----------------
def wait_for_crd(crd_name, timeout=120, interval=5):
    """Wait for a CRD to be established in the cluster."""
    print(f"⏳ Waiting for CRD {crd_name} to be established...")
    elapsed = 0
    while elapsed < timeout:
        try:
            # Check if the CRD exists
            subprocess.run(
                ["kubectl", "get", "crd", crd_name],
                capture_output=True,
                text=True,
                check=True
            )
            # Check the 'Established' condition
            result = subprocess.run(
                ["kubectl", "get", "crd", crd_name,
                 "-o", "jsonpath='{.status.conditions[?(@.type==\"Established\")].status}'"],
                capture_output=True,
                text=True,
                check=True
            )
            status = result.stdout.strip().strip("'")
            if status == "True":
                print(f"✅ CRD {crd_name} is ready.")
                return True
        except subprocess.CalledProcessError:
            pass  # CRD not found or condition not available yet
        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")
    print(f"❌ Timeout waiting for CRD {crd_name}")
    return False

# ---------------- WAIT FOR KAFKA ----------------
def wait_for_kafka(v1, timeout=300, interval=5):
    print("⏳ Waiting for Kafka cluster to be ready...")
    elapsed = 0
    while elapsed < timeout:
        try:
            pods = v1.list_namespaced_pod(KAFKA_NAMESPACE)
            # Verifica che tutti i pod con prefisso "demo-" siano Running
            kafka_pods = [p for p in pods.items if p.metadata.name.startswith("demo-")]
            if kafka_pods:
                all_running = all(p.status.phase == "Running" for p in kafka_pods)
                if all_running:
                    print("✅ Kafka cluster is ready!")
                    return True
        except Exception as e:
            print(f"Error checking Kafka pods: {e}")
        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")
    print("❌ Timeout waiting for Kafka cluster")
    return False

def create_or_update_kafka_configmap(v1):
    cm = client.V1ConfigMap(
        metadata=client.V1ObjectMeta(
            name="kafka-broker-config",
            namespace="knative-eventing"
        ),
        data={
            "bootstrap.servers": "demo-kafka-bootstrap.kafka.svc:9092",
            "default.topic.partitions": "3",
            "default.topic.replication.factor": "1"
        }
    )
    try:
        v1.create_namespaced_config_map("knative-eventing", cm)
        print("✅ Kafka ConfigMap created")
    except ApiException as e:
        if e.status == 409:
            v1.replace_namespaced_config_map("kafka-broker-config", "knative-eventing", cm)
            print("🔄 Kafka ConfigMap updated")
        else:
            raise

# ---------------- CREATE BROKER ----------------
def create_broker(custom_api):
    broker = {
        "apiVersion": "eventing.knative.dev/v1",
        "kind": "Broker",
        "metadata": {"name": BROKER_NAME, "namespace": NAMESPACE,
                     "annotations": {"eventing.knative.dev/broker.class": "Kafka"}},
        "spec": {
            "config": {
                "apiVersion": "v1",
                "kind": "ConfigMap",
                "name": "kafka-broker-config",
                "namespace": "knative-eventing"
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="eventing.knative.dev", version="v1",
            namespace=NAMESPACE, plural="brokers", body=broker
        )
        print("✅ Broker created")
    except ApiException as e:
        if e.status == 409:
            print("ℹ️ Broker already exists")
        else:
            raise

# ---------------- CREATE KNATIVE SERVICES ----------------
def create_knative_service(custom_api, name, tipo):
    body = {
        "apiVersion": "serving.knative.dev/v1",
        "kind": "Service",
        "metadata": {"name": name, "namespace": NAMESPACE},
        "spec": {
            "template": {
                "spec": {
                    "containers": [
                        {
                            "image": "tomasconti02/request-processor:v1",
                            "env": [{"name": "TIPO", "value": tipo},
                                    {"name": "DEBUG", "value": "true"} ] ############
                        }
                    ]
                }
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="serving.knative.dev", version="v1",
            namespace=NAMESPACE, plural="services", body=body
        )
        print(f"✅ Knative Service '{name}' created")
    except ApiException as e:
        if e.status == 409:
            print(f"ℹ️ Knative Service '{name}' already exists")
        else:
            raise

# ---------------- CREATE TRIGGERS ----------------
def create_triggers(custom_api):
    triggers = [
        {"name": "trigger-request", "type": "org.kubeflow.serving.inference.request", "service": "request-processor"},
        {"name": "trigger-response", "type": "org.kubeflow.serving.inference.response", "service": "response-processor"}
    ]
    for t in triggers:
        body = {
            "apiVersion": "eventing.knative.dev/v1",
            "kind": "Trigger",
            "metadata": {"name": t["name"], "namespace": NAMESPACE},
            "spec": {
                "broker": BROKER_NAME,
                "filter": {"attributes": {"type": t["type"]}},
                "subscriber": {"ref": {"apiVersion": "serving.knative.dev/v1", "kind": "Service", "name": t["service"]}}
            }
        }
        try:
            custom_api.create_namespaced_custom_object(
                group="eventing.knative.dev", version="v1",
                namespace=NAMESPACE, plural="triggers", body=body
            )
            print(f"✅ Trigger '{t['name']}' created")
        except ApiException as e:
            if e.status == 409:
                print(f"ℹ️ Trigger '{t['name']}' already exists")
            else:
                raise
def wait_for_webhook():
    print("⏳ Waiting for kafka-webhook-eventing pod...")
    v1 = client.CoreV1Api()
    while True:
        pods = v1.list_namespaced_pod("knative-eventing", label_selector="app=kafka-webhook-eventing")
        if pods.items and all(p.status.phase == "Running" for p in pods.items):
            print("✅ Webhook pod is ready")
            # Attendi qualche secondo in più per la registrazione del mutating webhook
            time.sleep(5)
            return
        time.sleep(2)

# ---------------- MAIN ----------------
def main():
    k8s_client = load_k8s_config()
    v1 = client.CoreV1Api(k8s_client)
    custom_api = client.CustomObjectsApi(k8s_client)

    # 0️⃣ Crea namespace Kafka
    create_namespace_if_not_exists(v1, KAFKA_NAMESPACE)
    time.sleep(5)
    # 1️⃣ Applica manifest Knative (usando Python client)
    for filepath in KNATIVE_MANIFESTS:
        #apply_yaml_from_file(k8s_client, filepath)
        apply_yaml_with_kubectl(filepath) 
        time.sleep(10) 

    """
    # Primi tre manifest
    for filepath in KNATIVE_MANIFESTS[:-1]:  # escludi l'ultimo
    apply_yaml_with_kubectl(filepath)
    # Attendi che il webhook sia pronto
    wait_for_pod_ready("knative-eventing", "app=kafka-webhook-eventing")
    # Attendi che il mutating webhook sia registrato (opzionale)
    time.sleep(10)
    # Poi applica l'ultimo manifesto
    apply_yaml_with_kubectl(KNATIVE_MANIFESTS[-1])
    """
    #---------------------OR-----------------------------------------#
    """
    # Applica solo i primi tre manifest
    for filepath in KNATIVE_MANIFESTS[:-1]:
    apply_yaml_with_kubectl(filepath)
    wait_for_webhook()  # aspetta il webhook
    # Applica l'ultimo manifesto (eventing-kafka-broker.yaml)
    apply_yaml_with_kubectl(KNATIVE_MANIFESTS[-1])
    """
    # 1️⃣a Attendi che i CRD di Knative siano pronti (broker CRD è essenziale)
    if not wait_for_crd("brokers.eventing.knative.dev", timeout=120):
        print("❌ Brokers CRD not ready. Abort deployment")
        return
    time.sleep(10)
    # 1️⃣b Attendi che tutti i pod nel namespace knative-eventing siano Running
    if not wait_for_namespace_pods_ready("knative-eventing", timeout=300):
        print("❌ Knative Eventing pods not ready. Abort deployment")
        return
    time.sleep(5)
    # 2️⃣ Applica Strimzi (usando kubectl per gestire CRD)
    apply_yaml_with_kubectl(STRIMZI_MANIFEST, namespace=KAFKA_NAMESPACE)
    time.sleep(10)
    # 2a️⃣ Attendi che il pod dell'operatore Strimzi sia pronto
    if not wait_for_pod_ready(KAFKA_NAMESPACE, "app=strimzi"):
        print("❌ Strimzi operator pod not ready. Abort deployment")
        return
    time.sleep(10)
    # 🔁 Attendi che la CRD Kafka sia pronta (con Established condition)
    if not wait_for_crd("kafkas.kafka.strimzi.io"):
        print("❌ Kafka CRD not ready. Abort deployment")
        return
    time.sleep(10)
    # 3️⃣ Applica cluster Kafka (usando kubectl)
    apply_yaml_with_kubectl(KAFKA_CLUSTER_MANIFEST, namespace=KAFKA_NAMESPACE)
    time.sleep(10)
    # 4️⃣ Attendi Kafka pronto
    if not wait_for_kafka(v1):
        print("❌ Kafka cluster non pronto. Abort deployment")
        return
    time.sleep(10)
    # 5️⃣ ConfigMap, Broker, Services, Triggers
    create_or_update_kafka_configmap(v1)
    time.sleep(10)  # breve pausa per propagazione
    create_broker(custom_api)
    time.sleep(10) 
    create_knative_service(custom_api, "request-processor", "request")
    time.sleep(10) 
    create_knative_service(custom_api, "response-processor", "response")
    time.sleep(10) 
    create_triggers(custom_api)

    print("\n🎉 Knative Eventing + Kafka setup completed!")

if __name__ == "__main__":
    main()
