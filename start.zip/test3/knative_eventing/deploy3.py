#!/usr/bin/env python3
r"""
kubectl get pods -n default -l serving.knative.dev/service=request-processor
kubectl get pods -n default -l serving.knative.dev/service=response-processor

kubectl logs -n default -l serving.knative.dev/service=request-processor --tail=20
kubectl logs -n default -l serving.knative.dev/service=response-processor --tail=20

kubectl logs -n default -l serving.knative.dev/service=request-processor -f | grep "instances" | wc -l
kubectl logs -n default -l serving.knative.dev/service=response-processor -f | grep "predictions\|embedding" | wc -l

check kafka topic work flow
kubectl exec -it -n kafka demo-pool-a-0 -- bash
bin/kafka-console-consumer.sh --bootstrap-server localhost:9092 --topic knative-broker-default-kafka-broker --from-beginning
"""
import time
import subprocess
from kubernetes import client, config, utils
from kubernetes.client.rest import ApiException
from kubernetes.client import ApiClient

# ---------------- CONFIG ----------------
NAMESPACE = "default"
KAFKA_NAMESPACE = "kafka"
BROKER_NAME = "kafka-broker"

KNATIVE_MANIFESTS = [
    "manifests/eventing-crds.yaml",
    "manifests/eventing-core.yaml",
    "manifests/eventing-kafka-controller.yaml",
    "manifests/eventing-kafka-broker.yaml",
]

STRIMZI_MANIFEST = "manifests/strimzi.yaml"
KAFKA_CLUSTER_MANIFEST = "kafka_cluster_conf.yaml"

# ---------------- LOAD CONFIG ----------------
def load_k8s_config():
    try:
        config.load_incluster_config()
        print("In-cluster config loaded")
    except:
        config.load_kube_config()
        print("Local kubeconfig loaded")
    return ApiClient()

# ---------------- CREATE NAMESPACE ----------------
def create_namespace_if_not_exists(v1, namespace):
    try:
        v1.read_namespace(namespace)
        print(f"ℹ️ Namespace '{namespace}' already exists")
    except ApiException as e:
        if e.status == 404:
            ns_body = client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
            v1.create_namespace(ns_body)
            print(f"✅ Namespace '{namespace}' created")
        else:
            raise

# ---------------- APPLY YAML WITH KUBECTL ----------------
def apply_yaml_with_kubectl(filepath, namespace=None):
    cmd = ["kubectl", "apply", "-f", filepath]
    if namespace:
        cmd.extend(["-n", namespace])
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        print(f"✅ Applied {filepath}")
        if result.stdout:
            print(result.stdout.strip())
    except subprocess.CalledProcessError as e:
        if "AlreadyExists" in e.stderr:
            print(f"ℹ️ {filepath} already exists, skipping")
        else:
            print(f"❌ Error applying {filepath}: {e.stderr}")
            raise

# ---------------- APPLY YAML WITH PYTHON CLIENT ----------------
def apply_yaml_from_file(k8s_client, filepath, namespace=None):
    try:
        utils.create_from_yaml(k8s_client, filepath, namespace=namespace)
        print(f"✅ Applied {filepath}")
    except Exception as e:
        if "AlreadyExists" in str(e):
            print(f"ℹ️ {filepath} already exists, skipping")
        else:
            print(f"❌ Error applying {filepath}: {e}")
            raise

# ---------------- WAIT FOR CRD ----------------
def wait_for_crd(crd_name, timeout=120):
    """Wait for a CRD to be established in the cluster."""
    print(f"⏳ Waiting for CRD {crd_name} to be established...")
    try:
        # Use kubectl wait to ensure the K8s API is actually ready to accept resources
        subprocess.run(
            ["kubectl", "wait", "--for=condition=Established", f"crd/{crd_name}", f"--timeout={timeout}s"],
            capture_output=True,
            text=True,
            check=True
        )
        print(f"✅ CRD {crd_name} is ready.")
        
        # Add a tiny buffer to allow the API server cache to sync
        time.sleep(3) 
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ Timeout or error waiting for CRD {crd_name}: {e.stderr}")
        return False

# ---------------- WAIT FOR KAFKA ----------------
def wait_for_kafka(v1, timeout=300, interval=5):
    print("⏳ Waiting for Kafka cluster to be ready...")
    elapsed = 0
    while elapsed < timeout:
        try:
            pods = v1.list_namespaced_pod(KAFKA_NAMESPACE)
            # Verifica che tutti i pod con prefisso "demo-" siano Running
            kafka_pods = [p for p in pods.items if p.metadata.name.startswith("demo-")]
            if kafka_pods:
                all_running = all(p.status.phase == "Running" for p in kafka_pods)
                if all_running:
                    print("✅ Kafka cluster is ready!")
                    return True
        except Exception as e:
            print(f"Error checking Kafka pods: {e}")
        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")
    print("❌ Timeout waiting for Kafka cluster")
    return False

def create_or_update_kafka_configmap(v1):
    cm = client.V1ConfigMap(
        metadata=client.V1ObjectMeta(
            name="kafka-broker-config",
            namespace="knative-eventing"
        ),
        data={
            "bootstrap.servers": "demo-kafka-bootstrap.kafka.svc:9092",
            "default.topic.partitions": "3",
            "default.topic.replication.factor": "1"
        }
    )
    try:
        v1.create_namespaced_config_map("knative-eventing", cm)
        print("✅ Kafka ConfigMap created")
    except ApiException as e:
        if e.status == 409:
            v1.replace_namespaced_config_map("kafka-broker-config", "knative-eventing", cm)
            print("🔄 Kafka ConfigMap updated")
        else:
            raise

# ---------------- CREATE BROKER ----------------
def create_broker(custom_api):
    broker = {
        "apiVersion": "eventing.knative.dev/v1",
        "kind": "Broker",
        "metadata": {"name": BROKER_NAME, "namespace": NAMESPACE,
                     "annotations": {"eventing.knative.dev/broker.class": "Kafka"}},
        "spec": {
            "config": {
                "apiVersion": "v1",
                "kind": "ConfigMap",
                "name": "kafka-broker-config",
                "namespace": "knative-eventing"
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="eventing.knative.dev", version="v1",
            namespace=NAMESPACE, plural="brokers", body=broker
        )
        print("✅ Broker created")
    except ApiException as e:
        if e.status == 409:
            print("ℹ️ Broker already exists")
        else:
            raise

# ---------------- CREATE KNATIVE SERVICES ----------------
def create_knative_service(custom_api, name, tipo):
    body = {
        "apiVersion": "serving.knative.dev/v1",
        "kind": "Service",
        "metadata": {"name": name, "namespace": NAMESPACE},
        "spec": {
            "template": {
                "spec": {
                    "containers": [
                        {
                            "image": "tomasconti02/request-processor:v1",
                            "env": [{"name": "TIPO", "value": tipo}]
                        }
                    ]
                }
            }
        }
    }
    try:
        custom_api.create_namespaced_custom_object(
            group="serving.knative.dev", version="v1",
            namespace=NAMESPACE, plural="services", body=body
        )
        print(f"✅ Knative Service '{name}' created")
    except ApiException as e:
        if e.status == 409:
            print(f"ℹ️ Knative Service '{name}' already exists")
        else:
            raise

# ---------------- CREATE TRIGGERS ----------------
def create_triggers(custom_api):
    triggers = [
        {"name": "trigger-request", "type": "org.kubeflow.serving.inference.request", "service": "request-processor"},
        {"name": "trigger-response", "type": "org.kubeflow.serving.inference.response", "service": "response-processor"}
    ]
    for t in triggers:
        body = {
            "apiVersion": "eventing.knative.dev/v1",
            "kind": "Trigger",
            "metadata": {"name": t["name"], "namespace": NAMESPACE},
            "spec": {
                "broker": BROKER_NAME,
                "filter": {"attributes": {"type": t["type"]}},
                "subscriber": {"ref": {"apiVersion": "serving.knative.dev/v1", "kind": "Service", "name": t["service"]}}
            }
        }
        try:
            custom_api.create_namespaced_custom_object(
                group="eventing.knative.dev", version="v1",
                namespace=NAMESPACE, plural="triggers", body=body
            )
            print(f"✅ Trigger '{t['name']}' created")
        except ApiException as e:
            if e.status == 409:
                print(f"ℹ️ Trigger '{t['name']}' already exists")
            else:
                raise

# ---------------- MAIN ----------------
def main():
    k8s_client = load_k8s_config()
    v1 = client.CoreV1Api(k8s_client)
    custom_api = client.CustomObjectsApi(k8s_client)

    # 0️⃣ Crea namespace Kafka
    create_namespace_if_not_exists(v1, KAFKA_NAMESPACE)

    # 1️⃣ Applica manifest Knative (usando Python client)
    for filepath in KNATIVE_MANIFESTS:
        apply_yaml_from_file(k8s_client, filepath)

    # 2️⃣ Applica Strimzi (usando kubectl per gestire CRD)
    apply_yaml_with_kubectl(STRIMZI_MANIFEST, namespace=KAFKA_NAMESPACE)

    # 🔁 Attendi che la CRD Kafka sia pronta (Updated function)
    if not wait_for_crd("kafkas.kafka.strimzi.io"):
        print("❌ Kafka CRD not ready. Abort deployment")
        return

    # 3️⃣ Applica cluster Kafka (usando kubectl)
    apply_yaml_with_kubectl(KAFKA_CLUSTER_MANIFEST, namespace=KAFKA_NAMESPACE)

    # 4️⃣ Attendi Kafka pronto
    if not wait_for_kafka(v1):
        print("❌ Kafka cluster non pronto. Abort deployment")
        return

    # 5️⃣ ConfigMap, Broker, Services, Triggers
    create_or_update_kafka_configmap(v1)
    time.sleep(3)  # breve pausa per propagazione
    create_broker(custom_api)
    create_knative_service(custom_api, "request-processor", "request")
    create_knative_service(custom_api, "response-processor", "response")
    create_triggers(custom_api)

    print("\n🎉 Knative Eventing + Kafka setup completed!")

if __name__ == "__main__":
    main()
