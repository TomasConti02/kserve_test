#!/usr/bin/env python3

import time
import json
import subprocess
from kubernetes import client, config, utils
from kubernetes.client.rest import ApiException
from kubernetes.client import ApiClient

# ---------------- CONFIG ----------------
NAMESPACE = "default"
KAFKA_NAMESPACE = "kafka"
BROKER_NAME = "kafka-broker"

KNATIVE_MANIFESTS = [
    "manifests/eventing-crds.yaml",
    "manifests/eventing-core.yaml",
    "manifests/eventing-kafka-controller.yaml",
    "manifests/eventing-kafka-broker.yaml",
]

STRIMZI_MANIFEST = "manifests/strimzi.yaml"
KAFKA_CLUSTER_MANIFEST = "kafka_cluster_conf.yaml"

# ---------------- LOAD CONFIG ----------------
def load_k8s_config():
    try:
        config.load_incluster_config()
        print("In-cluster config loaded")
    except:
        config.load_kube_config()
        print("Local kubeconfig loaded")
    return ApiClient()

# ---------------- CREATE NAMESPACE ----------------
def create_namespace_if_not_exists(v1, namespace):
    try:
        v1.read_namespace(namespace)
        print(f"ℹ️ Namespace '{namespace}' already exists")
    except ApiException as e:
        if e.status == 404:
            ns_body = client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
            v1.create_namespace(ns_body)
            print(f"✅ Namespace '{namespace}' created")
        else:
            raise

# ---------------- APPLY YAML ----------------
def apply_yaml_with_kubectl(filepath, namespace=None):
    cmd = ["kubectl", "apply", "-f", filepath]
    if namespace:
        cmd.extend(["-n", namespace])

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode == 0:
        print(f"✅ Applied {filepath}")
        if result.stdout:
            print(result.stdout.strip())
    else:
        print(f"❌ Error applying {filepath}:\n{result.stderr}")
        raise subprocess.CalledProcessError(result.returncode, cmd)

# ---------------- APPLY WITH RETRY ----------------
def apply_with_retry(filepath, namespace, retries=5, delay=5):
    for i in range(retries):
        try:
            apply_yaml_with_kubectl(filepath, namespace)
            return
        except subprocess.CalledProcessError:
            print(f"🔁 Retry {i+1}/{retries}...")
            time.sleep(delay)
    raise Exception(f"❌ Failed to apply {filepath} after {retries} retries")

# ---------------- APPLY YAML WITH PYTHON CLIENT ----------------
def apply_yaml_from_file(k8s_client, filepath, namespace=None):
    try:
        utils.create_from_yaml(k8s_client, filepath, namespace=namespace)
        print(f"✅ Applied {filepath}")
    except Exception as e:
        if "AlreadyExists" in str(e):
            print(f"ℹ️ {filepath} already exists")
        else:
            raise

# ---------------- WAIT FOR CRD (FIXED) ----------------
def wait_for_crd(crd_name, version="v1", timeout=120, interval=5):
    print(f"⏳ Waiting for CRD {crd_name} (version {version})...")
    elapsed = 0

    while elapsed < timeout:
        try:
            result = subprocess.run(
                ["kubectl", "get", "crd", crd_name, "-o", "json"],
                capture_output=True,
                text=True,
                check=True
            )

            crd = json.loads(result.stdout)

            # Check Established condition
            conditions = crd.get("status", {}).get("conditions", [])
            established = any(
                c["type"] == "Established" and c["status"] == "True"
                for c in conditions
            )

            # Check version exists
            versions = [v["name"] for v in crd.get("spec", {}).get("versions", [])]
            version_ready = version in versions

            if established and version_ready:
                print(f"✅ CRD {crd_name} is ready.")
                return True

        except Exception as e:
            print(f"Error checking CRD: {e}")

        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")

    print(f"❌ Timeout waiting for CRD {crd_name}")
    return False

# ---------------- WAIT FOR KAFKA ----------------
def wait_for_kafka(v1, timeout=300, interval=5):
    print("⏳ Waiting for Kafka cluster...")
    elapsed = 0

    while elapsed < timeout:
        pods = v1.list_namespaced_pod(KAFKA_NAMESPACE)
        kafka_pods = [p for p in pods.items if p.metadata.name.startswith("demo-")]

        if kafka_pods:
            all_running = all(p.status.phase == "Running" for p in kafka_pods)
            if all_running:
                print("✅ Kafka cluster is ready!")
                return True

        time.sleep(interval)
        elapsed += interval
        print(f"   Still waiting... ({elapsed}s)")

    print("❌ Timeout waiting for Kafka")
    return False

# ---------------- CONFIGMAP ----------------
def create_or_update_kafka_configmap(v1):
    cm = client.V1ConfigMap(
        metadata=client.V1ObjectMeta(
            name="kafka-broker-config",
            namespace="knative-eventing"
        ),
        data={
            "bootstrap.servers": "demo-kafka-bootstrap.kafka.svc:9092",
            "default.topic.partitions": "3",
            "default.topic.replication.factor": "1"
        }
    )

    try:
        v1.create_namespaced_config_map("knative-eventing", cm)
        print("✅ ConfigMap created")
    except ApiException as e:
        if e.status == 409:
            v1.replace_namespaced_config_map("kafka-broker-config", "knative-eventing", cm)
            print("🔄 ConfigMap updated")
        else:
            raise

# ---------------- MAIN ----------------
def main():
    k8s_client = load_k8s_config()
    v1 = client.CoreV1Api(k8s_client)

    # Namespace
    create_namespace_if_not_exists(v1, KAFKA_NAMESPACE)

    # Knative
    for filepath in KNATIVE_MANIFESTS:
        apply_yaml_from_file(k8s_client, filepath)

    # Strimzi
    apply_yaml_with_kubectl(STRIMZI_MANIFEST, namespace=KAFKA_NAMESPACE)

    # Wait CRD properly
    if not wait_for_crd("kafkas.kafka.strimzi.io"):
        return

    # EXTRA SAFETY DELAY (important!)
    time.sleep(10)

    # Kafka cluster (with retry)
    apply_with_retry(KAFKA_CLUSTER_MANIFEST, KAFKA_NAMESPACE)

    # Wait Kafka ready
    if not wait_for_kafka(v1):
        return

    # Config
    create_or_update_kafka_configmap(v1)

    print("\n🎉 Deployment completed successfully!")

if __name__ == "__main__":
    main()
