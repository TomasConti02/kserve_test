import tensorflow as tf
import numpy as np
import tensorflow as tf
import numpy as np

# 1. Definizione del modello con embedding ridotto
inputs = tf.keras.layers.Input(shape=(28, 28, 1), name="input")

# Blocco convolutivo 1
x = tf.keras.layers.Conv2D(32, (3, 3), activation="relu", padding="same")(inputs)
x = tf.keras.layers.MaxPooling2D((2, 2))(x)

# Blocco convolutivo 2
# 1. Definizione del modello con embedding ridotto
inputs = tf.keras.layers.Input(shape=(28, 28, 1), name="input")

# Blocco convolutivo 1
x = tf.keras.layers.Conv2D(32, (3, 3), activation="relu", padding="same")(inputs)
x = tf.keras.layers.MaxPooling2D((2, 2))(x)

# Blocco convolutivo 2
x = tf.keras.layers.Conv2D(64, (3, 3), activation="relu", padding="same")(x)
x = tf.keras.layers.MaxPooling2D((2, 2))(x)

# Riduzione dimensionale: Global Average Pooling + Dense per embedding compatto
x = tf.keras.layers.GlobalAveragePooling2D()(x)  # output: (64,)
embedding = tf.keras.layers.Dense(128, activation="relu", name="embedding")(x)

# 1. Definizione del modello con embedding ridotto
inputs = tf.keras.layers.Input(shape=(28, 28, 1), name="input")

# Blocco convolutivo 1
x = tf.keras.layers.Conv2D(32, (3, 3), activation="relu", padding="same")(inputs)
x = tf.keras.layers.MaxPooling2D((2, 2))(x)

# Blocco convolutivo 2
# Output probabilità (softmax) dall'embedding
probabilities = tf.keras.layers.Dense(10, activation="softmax", name="probabilities")(embedding)

# Output classe predetta (argmax)
predicted_class = tf.keras.layers.Lambda(
    lambda t: tf.argmax(t, axis=-1, output_type=tf.int32),
    name="predicted_class"
)(probabilities)

# Modello multi‑output
model = tf.keras.Model(
    inputs=inputs,
    outputs={
        "probabilities": probabilities,
        "embedding": embedding,
        "predicted_class": predicted_class,
    },
)

# 2. Compilazione – solo la loss sulle probabilità contribuisce realmente
model.compile(
    optimizer="adam",
    loss={
        "probabilities": "sparse_categorical_crossentropy",
        "embedding": "mse",          # dummy
        "predicted_class": "mse",    # dummy (non differenziabile)
    },
    loss_weights={
        "probabilities": 1.0,
        "embedding": 0.0,
        "predicted_class": 0.0,
    },
    metrics={"probabilities": "accuracy"},
)

# 3. Addestramento fittizio
print("Addestramento fittizio...")
x_train = np.random.random((100, 28, 28, 1)).astype("float32")
y_train = np.random.randint(10, size=(100,))

# Target dummy per gli output che non devono contribuire alla loss
dummy_embedding = np.zeros((100, 128), dtype=np.float32)   # shape adattata alla nuova embedding
dummy_predicted_class = np.zeros((100,), dtype=np.int32)

model.fit(
    x_train,
    {
        "probabilities": y_train,
        "embedding": dummy_embedding,
        "predicted_class": dummy_predicted_class,
    },
    epochs=1,
)

# 4. Esportazione per KServe / TensorFlow Serving
export_path = "./model_repo/1"
model.export(export_path)

print(f"Modello multi‑output salvato in: {export_path}")
