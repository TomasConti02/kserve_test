import numpy as np
import json

# Crea un array 28x28x1 di valori casuali compresi tra 0 e 1
image = np.random.rand(28, 28, 1).astype(float).tolist()

# Costruisci il payload
payload = {"instances": [image]}

# Salva su file
with open("input.json", "w") as f:
    json.dump(payload, f)

print("input.json generato.")
