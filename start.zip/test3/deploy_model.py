# kubectl get pods
# kubectl get inferenceservice
import time
import sys
from kubernetes import client, config
from kubernetes.client.rest import ApiException

from kserve import KServeClient
from kserve import V1beta1InferenceService
from kserve import V1beta1InferenceServiceSpec
from kserve import V1beta1PredictorSpec
from kserve import V1beta1ModelSpec
from kserve import V1beta1LoggerSpec
from kserve import V1beta1ModelFormat 

# ------------------------------------------------------------
# Configurazioni
# ------------------------------------------------------------
NAMESPACE = "default"
PVC_NAME = "simple-cnn-pvc"
PVC_STORAGE = "100Mi"
JOB_NAME = "simple-cnn-copy-job"
IMAGE = "tomasconti02/simple-cnn:embed-v2"

MODEL_PATH_IN_CONTAINER = "/app/model"
MOUNT_PATH = "/mnt/models"

INFERENCE_SERVICE_NAME = "simple-cnn"
STORAGE_URI = f"pvc://{PVC_NAME}/"

# ------------------------------------------------------------
# Utils
# ------------------------------------------------------------
def load_kube_config():
    try:
        config.load_incluster_config()
        print("Caricata configurazione in-cluster")
    except config.ConfigException:
        config.load_kube_config()
        print("Caricata configurazione da kubeconfig locale")


def create_pvc(v1_core):
    pvc = client.V1PersistentVolumeClaim(
        metadata=client.V1ObjectMeta(name=PVC_NAME, namespace=NAMESPACE),
        spec=client.V1PersistentVolumeClaimSpec(
            access_modes=["ReadWriteOnce"],
            resources=client.V1ResourceRequirements(
                requests={"storage": PVC_STORAGE}
            )
        )
    )
    try:
        v1_core.create_namespaced_persistent_volume_claim(
            namespace=NAMESPACE, body=pvc
        )
        print(f"PVC {PVC_NAME} creata")
    except ApiException as e:
        if e.status == 409:
            print(f"PVC {PVC_NAME} già esistente")
        else:
            raise


def create_job(batch_v1):
    job = client.V1Job(
        metadata=client.V1ObjectMeta(name=JOB_NAME, namespace=NAMESPACE),
        spec=client.V1JobSpec(
            ttl_seconds_after_finished=10,
            backoff_limit=1,
            template=client.V1PodTemplateSpec(
                spec=client.V1PodSpec(
                    restart_policy="OnFailure",
                    containers=[
                        client.V1Container(
                            name="model-writer",
                            image=IMAGE,
                            command=["/bin/sh", "-c"],
                            args=[
                                f"""
                                mkdir -p {MOUNT_PATH}/1;
                                cp -r {MODEL_PATH_IN_CONTAINER}/* {MOUNT_PATH}/1/;
                                ls -lh {MOUNT_PATH}/1;
                                """
                            ],
                            volume_mounts=[
                                client.V1VolumeMount(
                                    name="model-storage",
                                    mount_path=MOUNT_PATH
                                )
                            ]
                        )
                    ],
                    volumes=[
                        client.V1Volume(
                            name="model-storage",
                            persistent_volume_claim=client.V1PersistentVolumeClaimVolumeSource(
                                claim_name=PVC_NAME
                            )
                        )
                    ]
                )
            )
        )
    )

    try:
        batch_v1.create_namespaced_job(namespace=NAMESPACE, body=job)
        print(f"Job {JOB_NAME} avviato")
    except ApiException as e:
        if e.status == 409:
            print(f"Job {JOB_NAME} già esistente, ricreo")
            batch_v1.delete_namespaced_job(
                JOB_NAME, NAMESPACE, propagation_policy="Background"
            )
            time.sleep(2)
            batch_v1.create_namespaced_job(namespace=NAMESPACE, body=job)
        else:
            raise


def wait_for_job_completion(batch_v1, job_name, timeout_seconds=120):
    start = time.time()

    while time.time() - start < timeout_seconds:
        job = batch_v1.read_namespaced_job_status(job_name, NAMESPACE)

        if job.status.succeeded:
            print(f"Job {job_name} completato")
            return True

        if job.status.failed:
            print(f"Job {job_name} fallito")
            return False

        time.sleep(2)

    print("Timeout job")
    return False


def create_inferenceservice():
    kserve_client = KServeClient(config_file=None)

    logger = V1beta1LoggerSpec(
        mode="all",
        url="http://kafka-broker-ingress.knative-eventing.svc.cluster.local/default/kafka-broker"
    )

    predictor = V1beta1PredictorSpec(
        model=V1beta1ModelSpec(
            model_format=V1beta1ModelFormat(name="tensorflow"),  # ✅ FIX
            storage_uri=STORAGE_URI,
            resources=client.V1ResourceRequirements(
                requests={"cpu": "500m", "memory": "1Gi"},
                limits={"cpu": "1", "memory": "2Gi"}
            )
        ),
        logger=logger
    )

    isvc = V1beta1InferenceService(
        api_version="serving.kserve.io/v1beta1",
        kind="InferenceService",
        metadata=client.V1ObjectMeta(
            name=INFERENCE_SERVICE_NAME,
            namespace=NAMESPACE,
            annotations={
                "serving.kserve.io/deploymentMode": "Serverless"
            }
        ),
        spec=V1beta1InferenceServiceSpec(
            predictor=predictor
        )
    )

    try:
        kserve_client.get(INFERENCE_SERVICE_NAME, namespace=NAMESPACE)
        print("InferenceService esiste, patch")
        kserve_client.patch(
            INFERENCE_SERVICE_NAME,
            isvc,
            namespace=NAMESPACE
        )
    except RuntimeError as e:
        if "404" in str(e):
            print("InferenceService non esiste, creo")
            kserve_client.create(isvc)
        else:
            raise


# ------------------------------------------------------------
# MAIN
# ------------------------------------------------------------
def main():
    load_kube_config()

    v1_core = client.CoreV1Api()
    batch_v1 = client.BatchV1Api()
    create_pvc(v1_core)
    create_job(batch_v1)
    print("Attendo Job...")
    if not wait_for_job_completion(batch_v1, JOB_NAME):
        sys.exit(1)

    create_inferenceservice()

    print("✅ Deployment completato!")


if __name__ == "__main__":
    main()
