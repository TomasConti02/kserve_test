import json
import uuid
import subprocess

# Carica i dati di input come array (qui supponiamo sia lo stesso di input.json)
with open("input.json", "r") as f:
    input_data = json.load(f)

# Creiamo il CloudEvent corretto
cloudevent = {
    "specversion": "1.0",
    "type": "io.kserve.inference.request",
    "source": "/test",
    "id": str(uuid.uuid4()),
    "datacontenttype": "application/json",
    "data": {
        "inputs": [
            {
                "name": "input-0",
                "shape": [1, 28, 28, 1],  # Aggiorna se il tuo input ha un'altra shape
                "datatype": "FP32",        # Oppure INT32/INT64 secondo il modello
                "data": input_data["instances"][0]  # Assumendo che input.json abbia già "instances"
            }
        ]
    }
}

# Salva su file
with open("input_cloudevent.json", "w") as f:
    json.dump(cloudevent, f, indent=2)

print("input_cloudevent.json generato correttamente.")

# Invio automatico via curl
cmd = [
    "curl", "-v", "-X", "POST",
    "-H", "Content-Type: application/cloudevents+json",
    "-H", "Host: simple-cnn.default.example.com",
    "-d", "@input_cloudevent.json",
    "http://localhost:8080/v1/models/simple-cnn:predict"
]

subprocess.run(cmd)