#!/bin/bash

# Loop infinito
while true; do
  echo "Invio richiesta al modello $(date)"
  
  curl -v \
    -H "Host: simple-cnn.default.example.com" \
    -H "Content-Type: application/json" \
    http://localhost:8080/v1/models/simple-cnn:predict \
    -d @input.json
  
  echo -e "\n---\n"
  
  # Attendi 10 secondi
  sleep 10
done
