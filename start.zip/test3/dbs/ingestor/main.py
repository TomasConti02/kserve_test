from fastapi import FastAPI
import psycopg2
import os

app = FastAPI()

POSTGRES_HOST = os.getenv("POSTGRES_HOST", "postgres.drift-system.svc.cluster.local")
POSTGRES_DB = os.getenv("POSTGRES_DB", "drift_db")
POSTGRES_USER = os.getenv("POSTGRES_USER", "user")
POSTGRES_PASSWORD = os.getenv("POSTGRES_PASSWORD", "password123")

def create_table_if_not_exists():
    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS test (
            id SERIAL PRIMARY KEY,
            name TEXT NOT NULL
        )
    """)
    conn.commit()
    cur.close()
    conn.close()

@app.on_event("startup")
def startup():
    create_table_if_not_exists()

@app.post("/ingest")
def ingest_data(name: str):
    conn = psycopg2.connect(
        host=POSTGRES_HOST,
        database=POSTGRES_DB,
        user=POSTGRES_USER,
        password=POSTGRES_PASSWORD
    )
    cur = conn.cursor()
    cur.execute("INSERT INTO test (name) VALUES (%s)", (name,))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "saved", "data": name}

@app.get("/health")
def health():
    return {"status": "ok"}
