from fastapi import FastAPI
import psycopg2
import os

app = FastAPI()

@app.post("/ingest")
def ingest_data(name: str):
    conn = psycopg2.connect(
        host=os.getenv("POSTGRES_HOST", "postgres-postgresql"),
        database="drift_db",
        user="user",
        password="password123"
    )
    cur = conn.cursor()
    cur.execute("INSERT INTO test (name) VALUES (%s)", (name,))
    conn.commit()
    cur.close()
    conn.close()
    return {"status": "saved", "data": name}
