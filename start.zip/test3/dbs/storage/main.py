from fastapi import FastAPI
import boto3
from botocore.exceptions import ClientError

app = FastAPI()

# MinIO config
MINIO_ENDPOINT = "minio.drift-system.svc.cluster.local:9000"
ACCESS_KEY = "admin"
SECRET_KEY = "password123"
BUCKET_NAME = "test-bucket"

s3 = boto3.client(
    "s3",
    endpoint_url=f"http://{MINIO_ENDPOINT}",
    aws_access_key_id=ACCESS_KEY,
    aws_secret_access_key=SECRET_KEY,
    region_name="us-east-1",
)

@app.get("/minio-test")
def minio_test():
    try:
        # Create bucket if not exists
        if BUCKET_NAME not in [b['Name'] for b in s3.list_buckets()['Buckets']]:
            s3.create_bucket(Bucket=BUCKET_NAME)
        # Upload a test file
        s3.put_object(Bucket=BUCKET_NAME, Key="hello.txt", Body=b"Hello MinIO!")
        # Download it
        obj = s3.get_object(Bucket=BUCKET_NAME, Key="hello.txt")
        content = obj['Body'].read().decode()
        return {"status": "ok", "content": content}
    except ClientError as e:
        return {"status": "error", "message": str(e)}
