from fastapi import FastAPI
from qdrant_client import QdrantClient
import os

app = FastAPI()
client = QdrantClient(host=os.getenv("QDRANT_HOST", "qdrant"), port=6333)

@app.post("/vectorize")
def vectorize(text: str):
    # In un caso reale qui useresti un modello Sentence-Transformer
    collection_name = "test_collection"
    # Assicurati che la collezione esista (semplificato per test)
    return {"status": "connected", "qdrant_version": client.get_collections()}
