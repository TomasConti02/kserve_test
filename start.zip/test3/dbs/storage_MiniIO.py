from fastapi import FastAPI
import boto3
import os

app = FastAPI()

@app.post("/upload")
def upload():
    s3 = boto3.client('s3',
        endpoint_url=f"http://{os.getenv('MINIO_HOST', 'minio')}:9000",
        aws_access_key_id="admin",
        aws_secret_access_key="password123"
    )
    s3.put_object(Bucket='models', Key='test.txt', Body='Hello MinIO')
    return {"status": "uploaded"}
