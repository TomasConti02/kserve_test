from fastapi import FastAPI
from pydantic import BaseModel
from qdrant_client import QdrantClient
import os

app = FastAPI()

class TextRequest(BaseModel):
    text: str

client = QdrantClient(
    host=os.getenv("QDRANT_HOST", "qdrant.drift-system.svc.cluster.local"),
    port=6333
)

@app.get("/health")
def health():
    return {"status": "ok"}

@app.post("/vectorize")
def vectorize(req: TextRequest):
    try:
        collections = client.get_collections()
        return {
            "status": "connected",
            "collections": collections.dict()
        }
    except Exception as e:
        return {
            "status": "error",
            "message": str(e)
        }
