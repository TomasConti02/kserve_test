import os
import yaml
from kubernetes import client, config, utils
from kubernetes.client.rest import ApiException

# --------------------------------------------------
# CONFIG
# --------------------------------------------------
YAML_FOLDER = "./"   # folder where your *.yaml files are
NAMESPACE = "drift-system"

# --------------------------------------------------
# LOAD CONFIG
# --------------------------------------------------
def load_config():
    try:
        config.load_incluster_config()
        print("✅ In-cluster config loaded")
    except:
        config.load_kube_config()
        print("✅ Local kubeconfig loaded")


# --------------------------------------------------
# APPLY STANDARD K8S YAMLs (Deployment, Service, PVC, Secret)
# --------------------------------------------------
def apply_standard_yaml(api_client, file_path):
    try:
        utils.create_from_yaml(api_client, file_path)
        print(f"✔ Applied: {file_path}")
    except Exception as e:
        if "AlreadyExists" in str(e):
            print(f"⚠ Already exists: {file_path}")
        else:
            print(f"❌ Error applying {file_path}: {e}")


# --------------------------------------------------
# APPLY KNATIVE YAMLS via CustomObjectsApi
# --------------------------------------------------
def apply_knative_yaml(file_path):
    api_client = client.ApiClient()
    co_api = client.CustomObjectsApi(api_client)

    with open(file_path) as f:
        docs = yaml.safe_load_all(f)
        for doc in docs:
            if doc is None:
                continue

            kind = doc.get("kind")
            api_version = doc.get("apiVersion")
            metadata = doc.get("metadata", {})
            name = metadata.get("name")
            ns = metadata.get("namespace", NAMESPACE)

            if "/" in api_version:
                group, version = api_version.split("/", 1)
            else:
                group, version = "", api_version

            # naive plural: lowercase + "s"
            plural = kind.lower() + "s"

            try:
                co_api.create_namespaced_custom_object(
                    group=group,
                    version=version,
                    namespace=ns,
                    plural=plural,
                    body=doc
                )
                print(f"✔ Created {kind} {name} in {ns}")
            except ApiException as e:
                if e.status == 409:
                    print(f"⚠ {kind} {name} already exists in {ns}")
                else:
                    print(f"❌ Failed {kind} {name}: {e}")


# --------------------------------------------------
# MAIN
# --------------------------------------------------
def main():
    load_config()
    api_client = client.ApiClient()

    print("\n🚀 Applying DB infrastructure (MinIO, Postgres, Qdrant)...\n")

    # Apply standard K8s resources first
    for f in os.listdir(YAML_FOLDER):
        if f.endswith(".yaml") and "knative" not in f.lower():
            apply_standard_yaml(api_client, os.path.join(YAML_FOLDER, f))

    print("\n🚀 Applying Knative Services...\n")
    # Apply Knative services separately
    for f in os.listdir(YAML_FOLDER):
        if f.endswith(".yaml") and "knative" in f.lower():
            apply_knative_yaml(os.path.join(YAML_FOLDER, f))

    print("\n✅ DB + Knative stack deployed successfully!")


if __name__ == "__main__":
    main()
