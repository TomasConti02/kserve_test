#!/bin/bash

# Loop infinito
while true; do
  echo "Invio richiesta CloudEvent al modello $(date)"
  
  curl -v \
    -H "Host: simple-cnn.default.example.com" \
    -H "Content-Type: application/json" \
    -H "ce-specversion: 1.0" \
    -H "ce-type: io.kserve.inference.request" \
    -H "ce-source: test-script" \
    -H "ce-id: $(uuidgen)" \
    http://localhost:8080/v1/models/simple-cnn:predict \
    -d @input.json
  
  echo -e "\n---\n"
  
  sleep 10
done
